#include "Arduino.h"
void drawNumber(int num, uint8_t frame[8][12]);
